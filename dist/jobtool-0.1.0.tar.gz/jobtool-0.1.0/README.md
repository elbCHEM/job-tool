# job-tool
A set of functionallities that I often need when working on Niflheim
